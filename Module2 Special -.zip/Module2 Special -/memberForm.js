// const { template } = require('@babel/core')
// const memberManagement = require('./data/members.js')
// const { getMembers, findMember } = memberManagement()

import { memberManagement } from './data/members.js'
const { getMembers, findMember } = memberManagement()

//65130500070 Wanassanan Tri-apibanwongsa

function memberForm() {

  const addEventHandler = () => {

  }

  const memberHandler = () => {

  }

  return {
    addEventHandler
  }
}
// module.exports = memberForm
const { addEventHandler } = memberForm()
addEventHandler()
